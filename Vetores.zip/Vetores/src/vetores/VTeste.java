/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vetores;
import java.util.Scanner;
/**
 *
 * @author DouglasMoura
 */
public class VTeste {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner ler = new Scanner(System.in);
        
        System.out.print("QTDNota: ");
        int qtd = ler.nextInt();
        
        double vet[] = new double[qtd];
        int i;
        
        double media = 0, max = 0, fin = 0, min = 0;
        double teste = 0;
        for( i = 0; i < qtd; i++){
            System.out.print((i+1)+ "° Nota: ");
            double nota = ler.nextDouble();
            
            if(nota < 10.0){
            vet[i] = nota + 0.5;
            }
            if(nota >= 10.0){
            vet[i] = 10.0;
            }
            media = media + vet[i] / qtd;
            max = nota;
            
        }
        for (i = 0; i < qtd; i++){
                if (max <= vet[i]){
                    fin = max;
                }
                if (vet[i] <= max){
                    min = vet[i] - 0.5;
                }
            }
        for(i = 0; i < qtd; i++){
            System.out.println("N " + (i+1) +" Nota: "+vet[i]);
        }
        
            System.out.println("Vetor com: " +vet.length+ " posições.");
            System.out.println("Media da turma: "+media);
            System.out.println("Maior Nota: "+fin);
            System.out.println("Menor Nota: "+min);
           
            
        
        
    }
    
}
