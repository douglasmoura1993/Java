/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package languege;

import java.util.Locale;

/**
 *
 * @author DouglasMoura
 */
public class Languege {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Locale loc = Locale.getDefault();
        System.out.println(loc.getDisplayLanguage());
        System.out.println(loc.getCountry());
        System.out.println(loc.getLanguage());
    }
    
}
