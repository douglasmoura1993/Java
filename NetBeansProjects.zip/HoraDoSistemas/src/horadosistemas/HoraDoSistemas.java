package horadosistemas;
import java.util.Date;
/**
 *
 * @author DouglasMoura
 */
public class HoraDoSistemas {

  
    public static void main(String[] args) {
        // TODO code application logic here
        Date data = new Date();
        System.out.println("Data:" + data);
        System.out.println(data.toString());
        
        
    }
    
}
